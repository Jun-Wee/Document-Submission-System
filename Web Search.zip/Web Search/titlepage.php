<!DOCTYPE HTML>
 <html lang="en">
 <head>
  <meta charset="utf-8" />
  <meta name="description" content="title input for web search" />
  <meta name="keywords" content="PHP"/>
  <meta name="author" content="Sandali Jayasinghe" />
  <title>Title Input</title>
 </head>
 <body>
<form name="titleform" action="websearch.php" method="POST" novalidate>

Title: <input type="text" name="title" id="title">

<input type="submit" value="Search" name="submit" id="submit">

</form>
</body>
</html>